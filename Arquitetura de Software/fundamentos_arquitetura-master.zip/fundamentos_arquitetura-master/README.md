# Fundamentos de Arquitetura de Sisetemas

## Exercícios

* [Exercício 1](https://github.com/jeffhsta/fundamentos_arquitetura/tree/master/exercicio1)
* [Exercício 2](https://github.com/jeffhsta/fundamentos_arquitetura/tree/master/exercicio2)
* [Exercício 3](https://github.com/jeffhsta/fundamentos_arquitetura/tree/master/exercicio3)

## Tipos de arquiteturas

### Monolito

![Monolito](https://raw.githubusercontent.com/jeffhsta/fundamentos_arquitetura/master/monolito.png)

### Microserviços #1

![Monolito](https://raw.githubusercontent.com/jeffhsta/fundamentos_arquitetura/master/microservicos1.png)

### Microserviços #2

![Monolito](https://raw.githubusercontent.com/jeffhsta/fundamentos_arquitetura/master/microservicos2.png)

### Microserviços #3

![Monolito](https://raw.githubusercontent.com/jeffhsta/fundamentos_arquitetura/master/microservicos3.png)
