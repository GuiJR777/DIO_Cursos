# Exercício Final

Com base no Exercício 2, desligue um dos serviços criados e tente utilizar o sistema, faça isso para as duas versões e compare o resultado.

Na versão Microserviços #2, adicione uma ferramente de fila (como o RabbitMQ) e adicione na fila Dead letter queue a mensagem que teve durante sua tentativa de processar, para isso provoque um erro manualmente.
