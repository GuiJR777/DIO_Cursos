# Exercício 1

Escrever um pequeno sistema de qualquer tópico (exemplo biblioteca).

Esse sistema deve ter pelo menos três serviços, por exemplo:

* Serviço que gerencia usuários
* Serviço que gerencia os livros e suas locações
* Serviço que gera relatórios
