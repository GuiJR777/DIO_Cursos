# Exercício 2

Com base no sistema escrito no Exercício 1, crie uma cópia do sistema criado com o objetivo de ter uma versão na arquitetura Microserviços #1 e outro na arquitetura Microserviços #2

Use como message broker a ferramenta de sua preferência.
